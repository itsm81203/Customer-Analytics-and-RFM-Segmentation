USE EcommerceCustomerAnalytics;
SELECT * FROM dbo.RetailCleaned;